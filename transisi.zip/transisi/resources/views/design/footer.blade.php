        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <footer class="main-footer">
        <div class="pull-right hidden-xs">
         <a> Hari Ini :</a>
          @php 
         
        
          date_default_timezone_get("Asia/Jakarta"); 
          echo
          date("l, d-m-Y");
 

          @endphp
        </div>
        <strong>Copyright &copy; 2020 <a href="http://it.rosalia-indah.com">Transisi - Group</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->
  </body>
</html>
